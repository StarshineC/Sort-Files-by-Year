-=-=-= HOW TO USE =-=-=-

1. Open input.txt
2. Paste the path of the folder you want everything to be sorted into in the first line.
3. Paste a list of paths you want in the next lines.
4. Leave the last line empty
5. If you're using Windows, replace all "\" with "/".
6. Open the executable.

EXAMPLE input.txt CONTENTS
=================================================================
C:/[Censored for Demonstration]/out
C:/[Censored for Demonstration]/in
C:/[Censored for Demonstration]/otherIn

=================================================================